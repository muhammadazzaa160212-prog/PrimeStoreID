
const ORDER_KEY='psid_orders_v2';
const SETTING_KEY='psid_settings_v1';
const ADMIN_HASH='240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9'; // password: admin123
async function sha256(text){const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');}
function readJson(k,d=[]){try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(d))}catch(e){return d}}
function writeJson(k,v){localStorage.setItem(k,JSON.stringify(v))}
function esc(v){return String(v??'').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');}
function rupiah(n){return 'Rp'+Number(n||0).toLocaleString('id-ID')}
function orderText(o){return `ORDER BARU - PrimeStoreID\nInvoice: ${o.invoice}\nGame: ${o.game}\nProduk: ${o.product}\nUser ID: ${o.uid}\nServer: ${o.server}\nNickname: ${o.nick}\nWhatsApp: ${o.buyer}\nTotal: ${rupiah(o.total)}\nStatus: ${o.status}`}
function renderOrders(){
  const box=document.getElementById('ordersEditor'); if(!box)return;
  const orders=readJson(ORDER_KEY); document.getElementById('orderBadge').textContent=orders.filter(o=>o.status==='Pending').length;
  box.innerHTML=orders.length?'':'<p class="muted">Belum ada order masuk di browser ini.</p>';
  orders.forEach((o,i)=>box.innerHTML+=`<div class="order-admin-card"><div><b>${esc(o.invoice)} • ${esc(o.status)}</b><p>${esc(o.game)} - ${esc(o.product)}<br>${esc(o.nick)} / ${esc(o.uid)} (${esc(o.server)})<br><strong>${rupiah(o.total)}</strong> • ${esc(o.createdAt||'-')}</p></div>${o.proof?`<img src="${o.proof}" alt="Bukti bayar">`:''}<div class="admin-actions"><select data-status="${i}"><option ${o.status==='Pending'?'selected':''}>Pending</option><option ${o.status==='Diproses'?'selected':''}>Diproses</option><option ${o.status==='Selesai'?'selected':''}>Selesai</option><option ${o.status==='Cancel'?'selected':''}>Cancel</option></select><button class="mini" data-copy-order="${i}">Copy</button><button class="mini danger" data-del-order="${i}">Hapus</button></div></div>`);
  box.querySelectorAll('[data-status]').forEach(el=>el.onchange=e=>{const a=readJson(ORDER_KEY);a[+e.target.dataset.status].status=e.target.value;writeJson(ORDER_KEY,a);renderOrders();});
  box.querySelectorAll('[data-copy-order]').forEach(btn=>btn.onclick=e=>navigator.clipboard?.writeText(orderText(readJson(ORDER_KEY)[+e.target.dataset.copyOrder])).then(()=>alert('Order disalin.')));
  box.querySelectorAll('[data-del-order]').forEach(btn=>btn.onclick=e=>{const a=readJson(ORDER_KEY);a.splice(+e.target.dataset.delOrder,1);writeJson(ORDER_KEY,a);renderOrders();});
}
function renderSettings(){const st=Object.assign({maintenance:false},readJson(SETTING_KEY,{}));const b=document.getElementById('toggleMaintenance'); if(b){b.textContent=st.maintenance?'Maintenance ON':'Maintenance OFF';b.classList.toggle('primary',st.maintenance)}}


const STORAGE_KEY = 'psid_admin_data_v1';
const DEFAULT_GAMES = [
 ['Mobile Legends','MLBB','assets/mlbb.svg',[['5 Diamonds',2000],['12 Diamonds',4000],['28 Diamonds',9000],['44 Diamonds',13000],['86 Diamonds',22000],['172 Diamonds',43000],['257 Diamonds',64000],['344 Diamonds',85000],['429 Diamonds',106000],['514 Diamonds',126000],['706 Diamonds',172000],['Weekly Diamond Pass',28000]]],
 ['Free Fire','Garena','assets/freefire.svg',[['5 Diamonds',2000],['12 Diamonds',3000],['50 Diamonds',8000],['70 Diamonds',11000],['140 Diamonds',21000],['355 Diamonds',52000],['720 Diamonds',103000],['Member Mingguan',30000],['Member Bulanan',88000]]],
 ['PUBG Mobile','UC','assets/pubg.svg',[['60 UC',15000],['325 UC',76000],['660 UC',150000],['1800 UC',380000],['3850 UC',760000]]],
 ['Genshin Impact','Genesis','assets/genshin.svg',[['60 Genesis',15000],['300+30 Genesis',75000],['980+110 Genesis',229000],['1980+260 Genesis',459000]]],
 ['Valorant','Points','assets/valorant.svg',[['475 VP',56000],['1000 VP',112000],['2050 VP',224000],['3650 VP',390000]]],
 ['Honkai Star Rail','Shard','assets/hsr.svg',[['60 Shard',15000],['300+30 Shard',75000],['980+110 Shard',229000],['1980+260 Shard',459000]]],
 ['Call of Duty Mobile','CP','assets/codm.svg',[['63 CP',12000],['321 CP',56000],['645 CP',112000],['1373 CP',228000]]],
 ['Roblox','Robux','assets/roblox.svg',[['11 Robux',3000],['22 Robux',6000],['33 Robux',9000],['56 Robux',14000],['80 Robux',17000],['112 Robux',25000],['170 Robux',37000],['240 Robux',52000],['400 Robux',75000],['800 Robux',145000],['1.700 Robux',295000],['4.500 Robux',730000]]],
 ['Arena Breakout','Bonds','assets/arena.svg',[['60 Bonds',16000],['310 Bonds',76000],['630 Bonds',150000],['1580 Bonds',370000]]],
 ['Honor of Kings','Token','assets/hok.svg',[['80 Token',15000],['240 Token',45000],['400 Token',73000],['800 Token',145000]]],
 ['Sausage Man','Candy','assets/sausage.svg',[['60 Candy',15000],['300 Candy',72000],['680 Candy',150000],['1280 Candy',285000]]],
 ['Point Blank','Cash','assets/pb.svg',[['1200 Cash',12000],['2400 Cash',23000],['6000 Cash',57000],['12000 Cash',112000]]]
];
const DEFAULT_JOKI = [['Epic → Legend','Joki gendong aman dan cepat','Mulai Rp3.000/bintang'],['Legend → Mythic','Push rank sampai Mythic','Rp90.000'],['Mythic Grading','Selesaikan grading awal','Rp50.000'],['Per Bintang','Harga mulai per bintang','Mulai Rp1.000'],['Classic Winrate','Naikin WR hero pilihan','Rp10.000/win'],['Rekber Akun','Jasa rekber aman via WA','Mulai Rp3.000 - Rp5.000'],['Mabar Gendong','Main bareng party cepat','Chat Admin'],['Joki Event','Event MLBB dan misi harian','Chat Admin']];
const DEFAULT_TESTI = ['Order WDP aman, admin fast respon 🔥','Robux masuk, mantap PrimeStoreID','Joki Mythic cepet, no ribet','QRIS gampang, struk langsung WA','Harga murah buat langganan','Rekber aman, transaksi lancar'];
let data = loadData();
function clone(x){return JSON.parse(JSON.stringify(x));}
function loadData(){
  try{
    const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}');
    return {games: Array.isArray(saved.games)?saved.games:clone(DEFAULT_GAMES), joki: Array.isArray(saved.joki)?saved.joki:clone(DEFAULT_JOKI), testi: Array.isArray(saved.testi)?saved.testi:clone(DEFAULT_TESTI)};
  }catch(e){return {games:clone(DEFAULT_GAMES), joki:clone(DEFAULT_JOKI), testi:clone(DEFAULT_TESTI)};}
}
function saveData(){localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); alert('✅ Data berhasil disimpan. Cek halaman utama.');}
function requireLogin(){
  if(sessionStorage.getItem('psid_admin_login')==='yes'){showPanel();return;}
  document.getElementById('loginBtn').onclick=async()=>{
    const hash=await sha256(document.getElementById('adminPass').value);
    if(hash===ADMIN_HASH){sessionStorage.setItem('psid_admin_login','yes');showPanel();}
    else alert('Password salah bre.');
  };
}
function showPanel(){document.getElementById('loginBox').classList.add('hidden');document.getElementById('panelBox').classList.remove('hidden');renderAll();}
function renderAll(){renderOrders();renderSettings();renderGamesEditor();renderJokiEditor();renderTestiEditor();}
function renderGamesEditor(){
  const wrap=document.getElementById('gamesEditor'); wrap.innerHTML='';
  data.games.forEach((g,gi)=>{
    const box=document.createElement('div'); box.className='edit-box';
    box.innerHTML=`<div class="edit-title"><b>🎮 ${g[0]}</b><button class="mini danger" data-del-game="${gi}">Hapus Game</button></div>
      <div class="mini-grid"><label>Nama Game<input data-g="${gi}" data-field="0" value="${escapeHtml(g[0])}"></label><label>Kategori<input data-g="${gi}" data-field="1" value="${escapeHtml(g[1])}"></label><label>Path Gambar<input data-g="${gi}" data-field="2" value="${escapeHtml(g[2])}"></label></div>
      <div class="product-table" id="products-${gi}"></div><button class="mini" data-add-product="${gi}">+ Tambah Produk</button>`;
    wrap.appendChild(box);
    renderProducts(gi);
  });
  wrap.querySelectorAll('[data-g][data-field]').forEach(inp=>inp.oninput=e=>{data.games[+e.target.dataset.g][+e.target.dataset.field]=e.target.value;});
  wrap.querySelectorAll('[data-del-game]').forEach(btn=>btn.onclick=e=>{if(confirm('Hapus game ini?')){data.games.splice(+e.target.dataset.delGame,1);renderGamesEditor();}});
  wrap.querySelectorAll('[data-add-product]').forEach(btn=>btn.onclick=e=>{data.games[+e.target.dataset.addProduct][3].push(['Produk Baru',0]);renderGamesEditor();});
}
function renderProducts(gi){
  const el=document.getElementById(`products-${gi}`); el.innerHTML='<div class="table-head"><span>Produk</span><span>Harga</span><span>Aksi</span></div>';
  data.games[gi][3].forEach((p,pi)=>{
    el.innerHTML += `<div class="product-row"><input data-prod-name="${gi}:${pi}" value="${escapeHtml(p[0])}"><input type="number" data-prod-price="${gi}:${pi}" value="${p[1]}"><button class="mini danger" data-del-prod="${gi}:${pi}">Hapus</button></div>`;
  });
  el.querySelectorAll('[data-prod-name]').forEach(inp=>inp.oninput=e=>{const [g,p]=e.target.dataset.prodName.split(':').map(Number);data.games[g][3][p][0]=e.target.value;});
  el.querySelectorAll('[data-prod-price]').forEach(inp=>inp.oninput=e=>{const [g,p]=e.target.dataset.prodPrice.split(':').map(Number);data.games[g][3][p][1]=Number(e.target.value||0);});
  el.querySelectorAll('[data-del-prod]').forEach(btn=>btn.onclick=e=>{const [g,p]=e.target.dataset.delProd.split(':').map(Number);data.games[g][3].splice(p,1);renderGamesEditor();});
}
function renderJokiEditor(){
  const wrap=document.getElementById('jokiEditor');wrap.innerHTML='';
  data.joki.forEach((j,i)=>{wrap.innerHTML+=`<div class="edit-box small"><div class="mini-grid three"><input data-joki="${i}:0" value="${escapeHtml(j[0])}" placeholder="Nama jasa"><input data-joki="${i}:1" value="${escapeHtml(j[1])}" placeholder="Deskripsi"><input data-joki="${i}:2" value="${escapeHtml(j[2])}" placeholder="Harga"><button class="mini danger" data-del-joki="${i}">Hapus</button></div></div>`;});
  wrap.querySelectorAll('[data-joki]').forEach(inp=>inp.oninput=e=>{const [i,f]=e.target.dataset.joki.split(':').map(Number);data.joki[i][f]=e.target.value;});
  wrap.querySelectorAll('[data-del-joki]').forEach(btn=>btn.onclick=e=>{data.joki.splice(+e.target.dataset.delJoki,1);renderJokiEditor();});
}
function renderTestiEditor(){
  const wrap=document.getElementById('testiEditor');wrap.innerHTML='';
  data.testi.forEach((t,i)=>{wrap.innerHTML+=`<div class="product-row"><input data-testi="${i}" value="${escapeHtml(t)}"><button class="mini danger" data-del-testi="${i}">Hapus</button></div>`;});
  wrap.querySelectorAll('[data-testi]').forEach(inp=>inp.oninput=e=>data.testi[+e.target.dataset.testi]=e.target.value);
  wrap.querySelectorAll('[data-del-testi]').forEach(btn=>btn.onclick=e=>{data.testi.splice(+e.target.dataset.delTesti,1);renderTestiEditor();});
}
function escapeHtml(v){return String(v).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');}
document.getElementById('addGame').onclick=()=>{data.games.push(['Game Baru','Kategori','assets/mlbb.svg',[['Produk Baru',0]]]);renderGamesEditor();};
document.getElementById('addJoki').onclick=()=>{data.joki.push(['Jasa Baru','Deskripsi jasa','Chat Admin']);renderJokiEditor();};
document.getElementById('addTesti').onclick=()=>{data.testi.push('Testimoni baru');renderTestiEditor();};
document.getElementById('saveAll').onclick=saveData;
document.getElementById('logoutBtn').onclick=()=>{sessionStorage.removeItem('psid_admin_login');location.reload();};
document.getElementById('toggleMaintenance').onclick=()=>{const st=Object.assign({maintenance:false},readJson(SETTING_KEY,{}));st.maintenance=!st.maintenance;writeJson(SETTING_KEY,st);renderSettings();};
document.getElementById('clearOrders').onclick=()=>{const keep=readJson(ORDER_KEY).filter(o=>!['Selesai','Cancel'].includes(o.status));writeJson(ORDER_KEY,keep);renderOrders();};
document.getElementById('resetAll').onclick=()=>{if(confirm('Balikin semua ke data bawaan?')){localStorage.removeItem(STORAGE_KEY);data=loadData();renderAll();alert('Data sudah direset.');}};
document.getElementById('exportData').onclick=()=>{document.getElementById('backupBox').value=JSON.stringify(data,null,2);};
document.getElementById('importData').onclick=()=>{try{const imported=JSON.parse(document.getElementById('backupBox').value); if(!Array.isArray(imported.games)) throw new Error('Format salah'); data=imported; saveData(); renderAll();}catch(e){alert('JSON salah / format tidak cocok.')}};
requireLogin();
